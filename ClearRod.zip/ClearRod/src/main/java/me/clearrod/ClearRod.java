package me.clearrod;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public class ClearRod extends JavaPlugin implements Listener {

    private NamespacedKey key;

    @Override
    public void onEnable() {
        key = new NamespacedKey(this, "clear_rod");
        getServer().getPluginManager().registerEvents(this, this);
    }

    // /clearrod  -> يعطيك الصنارة
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!p.hasPermission("clearrod.use")) {
            p.sendMessage(ChatColor.RED + "ما عندك صلاحية.");
            return true;
        }
        ItemStack rod = new ItemStack(Material.FISHING_ROD);
        ItemMeta meta = rod.getItemMeta();
        meta.setDisplayName(ChatColor.RED + "صنارة المسح");
        meta.setLore(List.of(ChatColor.GRAY + "اصطد لاعب وتنمسح أغراضه"));
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        rod.setItemMeta(meta);
        p.getInventory().addItem(rod);
        p.sendMessage(ChatColor.GREEN + "استلمت الصنارة.");
        return true;
    }

    @EventHandler
    public void onFish(PlayerFishEvent e) {
        if (e.getState() != PlayerFishEvent.State.CAUGHT_ENTITY) return;
        if (!(e.getCaught() instanceof Player target)) return;

        Player fisher = e.getPlayer();
        if (!fisher.hasPermission("clearrod.use")) return;

        ItemStack hand = fisher.getInventory().getItemInMainHand();
        if (!hand.hasItemMeta() || !hand.getItemMeta().getPersistentDataContainer()
                .has(key, PersistentDataType.BYTE)) return;

        target.getInventory().clear();
        target.getInventory().setArmorContents(new ItemStack[4]);
        target.getInventory().setItemInOffHand(null);

        target.sendMessage(ChatColor.RED + "تم مسح أغراضك بواسطة " + fisher.getName());
        fisher.sendMessage(ChatColor.GREEN + "تم مسح أغراض " + target.getName());
    }
}
